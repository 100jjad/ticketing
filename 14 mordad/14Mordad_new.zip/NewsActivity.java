package com.example.ssoheyli.ticketing_newdesign.News;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Handler;
import android.support.constraint.ConstraintLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.content.ContextCompat;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.LinearSmoothScroller;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Base64;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ssoheyli.ticketing_newdesign.Helpfull.API;
import com.example.ssoheyli.ticketing_newdesign.Helpfull.Config;
import com.example.ssoheyli.ticketing_newdesign.Helpfull.Constans;
import com.example.ssoheyli.ticketing_newdesign.Model.Model_News_Groups;
import com.example.ssoheyli.ticketing_newdesign.Model.NewsGroupModel;
import com.example.ssoheyli.ticketing_newdesign.Model.News_Post_Category;
import com.example.ssoheyli.ticketing_newdesign.R;
import com.github.ybq.android.spinkit.sprite.Sprite;
import com.github.ybq.android.spinkit.style.Circle;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class NewsActivity extends AppCompatActivity implements SwipeRefreshLayout.OnRefreshListener {

    private ProgressBar loader;
    private Toolbar LL1;
    private SwipeRefreshLayout refresher;
    private RecyclerView newsGroupList;
    private NewsGroupAdapter adapter;
    private ImageView im1;
    private TextView tv1;
    FloatingActionButton btn_to_top;
    private List<Model_News_Groups> modelNewsGroups;
    private List<NewsGroupModel> newsGroupModels;
    public static boolean flag_first = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTheme(Constans.theme);
        setContentView(R.layout.activity_news);
        flag_first = true;

        initViews();

        setupToolbar();

        click_btn();

        //Progressbar color
        Sprite circle = new Circle();
        circle.setColor(ContextCompat.getColor(this, Constans.colorprimary));
        loader.setIndeterminateDrawable(circle);

        loadData();

    }

    private void click_btn() {
        btn_to_top.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                newsGroupList.scrollTo(0,0);
//                newsGroupList.scrollBy(0,0);
//                newsGroupList.scrollToPosition(0);

                RecyclerView.SmoothScroller smoothScroller = new LinearSmoothScroller(NewsActivity.this) {
                    @Override
                    protected int getVerticalSnapPreference() {
                        return LinearSmoothScroller.SNAP_TO_START;
                    }
                };

                smoothScroller.setTargetPosition(0);
                if (newsGroupList.getLayoutManager() != null) {
                    newsGroupList.getLayoutManager().startSmoothScroll(smoothScroller);
                }
            }
        });
    }

    private void setupToolbar() {
        Toolbar toolbar = findViewById(R.id.LL1);
        setSupportActionBar(toolbar);
        toolbar.setTitleTextColor(ContextCompat.getColor(this, R.color.white));
        toolbar.setBackgroundColor(ContextCompat.getColor(this, Constans.colorprimary));
        getSupportActionBar().setTitle("");
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeButtonEnabled(true);
    }

    private void initViews() {
        loader = findViewById(R.id.loader);
        refresher = findViewById(R.id.refresher);
        refresher.setOnRefreshListener(this);
        newsGroupList = findViewById(R.id.news_group_list);
        im1 = findViewById(R.id.im1);
        tv1 = findViewById(R.id.tv1);
        btn_to_top = findViewById(R.id.floatactionbutton);
    }

    private void loadData() {
        Retrofit loadCategories = new Retrofit.Builder().baseUrl(Config.getBaseUrl()).addConverterFactory(GsonConverterFactory.create()).build();
        API api = loadCategories.create(API.class);
        News_Post_Category postCategory = new News_Post_Category();
        postCategory.setLangID(1065);
        final Call<List<Model_News_Groups>> models = api.getNewsGroups(postCategory);
        models.enqueue(new Callback<List<Model_News_Groups>>() {
            @Override
            public void onResponse(Call<List<Model_News_Groups>> call, Response<List<Model_News_Groups>> response) {
                if (response.isSuccessful()) {
                    modelNewsGroups = new ArrayList<>();
                    newsGroupModels = new ArrayList<>();

                    modelNewsGroups = response.body();
                    Log.i("NewsActivity", "MODEL " + modelNewsGroups.size());

                    if (modelNewsGroups.size() == 0) {
                        tv1.setTextColor(ContextCompat.getColor(NewsActivity.this, Constans.colorprimary));
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                            im1.setImageTintList(ContextCompat.getColorStateList(NewsActivity.this, Constans.colorprimary));
                        }
                        loader.setVisibility(View.GONE);
                        im1.setImageResource(R.drawable.ti1);
                        tv1.setText(getResources().getString(R.string.nothing_exist));
                    } else {

                        for (int i = 0; i < modelNewsGroups.size(); i++) {

                            byte[] bytes = Base64.decode(modelNewsGroups.get(i).getImage(), Base64.DEFAULT);
                            Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);

                            NewsGroupModel model = new NewsGroupModel(
                                    modelNewsGroups.get(i).getTitle(),
                                    bitmap,
                                    modelNewsGroups.get(i).getId()
                            );

                            newsGroupModels.add(model);

                        }

                        adapter = new NewsGroupAdapter(NewsActivity.this, newsGroupModels);

                        // LINEAR
                        LinearLayoutManager linearVertical = new LinearLayoutManager(NewsActivity.this, LinearLayoutManager.VERTICAL, false);

                        // GRID
                        GridLayoutManager gridHorizontal = new GridLayoutManager(NewsActivity.this, 2, GridLayoutManager.VERTICAL, false);

                        newsGroupList.setLayoutManager(linearVertical);
                        newsGroupList.setAdapter(adapter);
                        adapter.notifyDataSetChanged();
                        loader.setVisibility(View.GONE);
                    }
                } else {
                    Toast.makeText(NewsActivity.this, getString(R.string.server_error_news), Toast.LENGTH_SHORT).show();
                    loader.setVisibility(View.GONE);
                }
            }

            @Override
            public void onFailure(Call<List<Model_News_Groups>> call, Throwable t) {
                loader.setVisibility(View.GONE);
                Toast.makeText(NewsActivity.this, "Connection Lost", Toast.LENGTH_SHORT).show();
            }
        });

    }

    public void goBack(View view) {
        finish();
    }

    @Override
    public void onRefresh() {
        refresher.setColorSchemeColors(ContextCompat.getColor(this, Constans.colorprimary));
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                loadData();
                refresher.setRefreshing(false);
            }
        }, 2000);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }


    @Override
    protected void onResume() {
        super.onResume();
        if (!flag_first) {
            loader.setVisibility(View.GONE);
        }
    }
}
