package com.example.ssoheyli.ticketing_newdesign.News;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Handler;
import android.support.constraint.ConstraintLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.content.ContextCompat;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.LinearSmoothScroller;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Base64;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ssoheyli.ticketing_newdesign.Helpfull.API;
import com.example.ssoheyli.ticketing_newdesign.Helpfull.Config;
import com.example.ssoheyli.ticketing_newdesign.Helpfull.Constans;
import com.example.ssoheyli.ticketing_newdesign.Helpfull.FakeDataGenerator;
import com.example.ssoheyli.ticketing_newdesign.Model.Model_News_NewsItems;
import com.example.ssoheyli.ticketing_newdesign.Model.NewsItemPostModel;
import com.example.ssoheyli.ticketing_newdesign.Model.NewsItemsModel;
import com.example.ssoheyli.ticketing_newdesign.R;
import com.github.ybq.android.spinkit.sprite.Sprite;
import com.github.ybq.android.spinkit.style.Circle;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import static com.example.ssoheyli.ticketing_newdesign.News.NewsActivity.flag_first;

public class NewsItemsActivity extends AppCompatActivity implements SwipeRefreshLayout.OnRefreshListener {

    private ProgressBar loader;
    private Toolbar LL1;
    private SwipeRefreshLayout refresher;
    private TextView title;
    private ImageView im1;
    private TextView tv1;
    FloatingActionButton btn_to_top;
    private RecyclerView itemsList;
    private NewsItemsAdapter adapter;
    private List<Model_News_NewsItems> model_news_newsItems;
    private List<NewsItemsModel> newsItemsModels;
    private String category;
    private int newsId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTheme(Constans.theme);
        setContentView(R.layout.activity_news_items);
        flag_first = false;
        setupToolbar();
        initViews();

        //Progressbar color
        Sprite circle = new Circle();
        circle.setColor(ContextCompat.getColor(this, Constans.colorprimary));
        loader.setIndeterminateDrawable(circle);
        loader.setVisibility(View.VISIBLE);

        click_btn();

        loadData();
    }

    private void setupToolbar() {
        Toolbar toolbar = findViewById(R.id.LL1);
        setSupportActionBar(toolbar);
        toolbar.setTitleTextColor(ContextCompat.getColor(this, R.color.white));
        toolbar.setBackgroundColor(ContextCompat.getColor(this, Constans.colorprimary));
        getSupportActionBar().setTitle("");
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeButtonEnabled(true);

    }

    private void click_btn() {
        btn_to_top.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                newsGroupList.scrollTo(0,0);
//                newsGroupList.scrollBy(0,0);
//                newsGroupList.scrollToPosition(0);

                RecyclerView.SmoothScroller smoothScroller = new LinearSmoothScroller(NewsItemsActivity.this) {
                    @Override
                    protected int getVerticalSnapPreference() {
                        return LinearSmoothScroller.SNAP_TO_START;
                    }
                };

                smoothScroller.setTargetPosition(0);
                if (itemsList.getLayoutManager() != null) {
                    itemsList.getLayoutManager().startSmoothScroll(smoothScroller);
                }

//                itemsList.scrollToPosition(0);

            }
        });
    }


    private void initViews() {
        title = findViewById(R.id.category);

        // get category
        if (getIntent().getExtras() != null) {
            category = getIntent().getStringExtra("category");
            newsId = getIntent().getIntExtra("id", 0);
            title.setText(category);
        }

        btn_to_top = findViewById(R.id.floatactionbutton);
        loader = findViewById(R.id.loader);
        refresher = findViewById(R.id.refresher);
        refresher.setOnRefreshListener(this);
        im1 = findViewById(R.id.im1);
        tv1 = findViewById(R.id.tv1);
        itemsList = findViewById(R.id.news_item_list);
    }


    private void loadData() {

        Retrofit loadItems = new Retrofit.Builder().baseUrl(Config.getBaseUrl()).addConverterFactory(GsonConverterFactory.create()).build();
        API api = loadItems.create(API.class);
        NewsItemPostModel postModel = new NewsItemPostModel();
        postModel.setCategoryID(newsId);
        postModel.setSkip(0);
        postModel.setTake(10);
        postModel.setLangID(1065);
        Call<List<Model_News_NewsItems>> models = api.getNewsItems(postModel);
        models.enqueue(new Callback<List<Model_News_NewsItems>>() {
            @Override
            public void onResponse(Call<List<Model_News_NewsItems>> call, Response<List<Model_News_NewsItems>> response) {
                if (response.isSuccessful()) {
                    model_news_newsItems = new ArrayList<>();
                    newsItemsModels = new ArrayList<>();

                    model_news_newsItems = response.body();

                    if (model_news_newsItems.size() == 0) {
                        tv1.setTextColor(ContextCompat.getColor(NewsItemsActivity.this, Constans.colorprimary));
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                            im1.setImageTintList(ContextCompat.getColorStateList(NewsItemsActivity.this, Constans.colorprimary));
                        }
                        loader.setVisibility(View.INVISIBLE);
                        im1.setImageResource(R.drawable.ti1);
                        tv1.setText(getResources().getString(R.string.nothing_exist));
                    } else {

                        for (int i = 0; i < model_news_newsItems.size(); i++) {

                            byte[] bytes = Base64.decode(model_news_newsItems.get(i).getImage(), Base64.DEFAULT);
                            Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);

                            NewsItemsModel model = new NewsItemsModel(
                                    model_news_newsItems.get(i).getId(),
                                    model_news_newsItems.get(i).getTitle(),
                                    model_news_newsItems.get(i).getDate(),
                                    model_news_newsItems.get(i).getDescription(),
                                    bitmap
                            );

                            newsItemsModels.add(model);
                        }

                        adapter = new NewsItemsAdapter(NewsItemsActivity.this, newsItemsModels);

                        // LINEAR
                        LinearLayoutManager linearVertical = new LinearLayoutManager(NewsItemsActivity.this, LinearLayoutManager.VERTICAL, false);

                        itemsList.setLayoutManager(linearVertical);
                        itemsList.setAdapter(adapter);
                        adapter.notifyDataSetChanged();
                        loader.setVisibility(View.INVISIBLE);
                    }
                } else {
                    Toast.makeText(NewsItemsActivity.this, getString(R.string.server_error_news), Toast.LENGTH_SHORT).show();
                    loader.setVisibility(View.INVISIBLE);
                }
            }

            @Override
            public void onFailure(Call<List<Model_News_NewsItems>> call, Throwable t) {
                loader.setVisibility(View.INVISIBLE);
                Toast.makeText(NewsItemsActivity.this, "Connection Lost", Toast.LENGTH_SHORT).show();
            }
        });


    }

    public void goBack(View view) {
        finish();
    }

    @Override
    public void onRefresh() {
        refresher.setColorSchemeColors(ContextCompat.getColor(this, Constans.colorprimary));
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                loadData();
                refresher.setRefreshing(false);
            }
        }, 2000);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onResume() {
        super.onResume();
        flag_first = false;
    }
}
